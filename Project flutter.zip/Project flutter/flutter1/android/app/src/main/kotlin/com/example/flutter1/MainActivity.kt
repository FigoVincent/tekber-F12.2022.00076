package com.example.flutter1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
